__version__ = '0.1'

from .FIRDeconvolution import FIRDeconvolution
